
package servlets;

import business.Student;
import business.StudentIO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author acmor
 */
public class ClassListServlet extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String URL="/ClassList.jsp", msg=""; String path = "";
        ArrayList<Student> stulist = null;
        
        try {
            ServletContext context = getServletContext();
            int choice = Integer.parseInt(request.getParameter("filetype"));
            if (choice == 1) {
                path = context.getRealPath("/WEB-INF/classlist.txt");
                stulist = StudentIO.getStudentList(path);   
            } else if (choice == 2) {
                path = context.getRealPath("/WEB-INF/classlist.ser");
                stulist = StudentIO.getStudentListSer(path);
            }
            msg = "Button choice was: " + choice;
            request.setAttribute("stulist", stulist);
             }
        catch (Exception e) {
            msg = "ClassList servlet error: " + e.getMessage();
        }
        request.setAttribute("msg", msg);
        RequestDispatcher disp =               //new object
                getServletContext().getRequestDispatcher(URL);
        disp.forward(request, response);
    }
    }


