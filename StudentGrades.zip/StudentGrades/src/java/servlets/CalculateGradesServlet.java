/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import business.Student;
import business.StudentIO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author acmor
 */
public class CalculateGradesServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String msg ="", URL="/StudentGrade.jsp";
        Student s = null;
        try {
            s = new Student();
            String sid = request.getParameter("sid");
            if (sid.isEmpty()) {
                msg += "Missing Student ID.<br>";
            } else {
                s.setSid(sid);
            }
            String lnm = request.getParameter("lastname");
            if (lnm.isEmpty()) {
                msg += "Missing Last Name.<br>";
            } else {
                s.setLastnm(lnm);
            }
            String fnm = request.getParameter("firstname");
            if (fnm.isEmpty()) {
                msg += "Missing First Name.<br>";
            } else {
                s.setFirstnm(fnm);   
            }
            String scores[] = { "q1", "q2", "q3", "q4", "q5", "qmkup", "midterm", 
                "probs", "final" };
            for (String score : scores) {
                String scr = request.getParameter(score);
                if (!scr.isEmpty()) {
                    try {
                        double sval = Double.parseDouble(scr);
                        if (sval < 0 || sval > 125) {
                            throw new NumberFormatException(score + "out of bounds.");
                        } else {
                            msg += score + " is missing.<br>";
                            }
                   
                        switch (score) {
                            case "q1":
                                s.setQ1(sval);
                                break;
                            case "q2":
                                s.setQ2(sval);
                                break;
                            case "q3":
                                s.setQ3(sval);
                                break;
                            case "q4":
                                s.setQ4(sval);
                                break;
                            case "q5":
                                s.setQ5(sval);
                                break;
                            case "qmkup":
                                s.setQm(sval);
                                break;
                            case "midterm":
                                s.setMt(sval);
                                break;
                            case "probs":
                                s.setPr(sval);
                                break;
                            case "final":
                                s.setFe(sval);
                                break;   
                        }
                    }  catch (NumberFormatException e) {
                        msg += "Error on " + score + ": " + e.getMessage() + "<br>";
                    } 
                }
      
                if (!msg.isEmpty()) {
                    URL = "/students.jsp";
                    
                } else {
                    ServletContext context = getServletContext();
                    String pathtxt = context.getRealPath("/WEB-INF/classlist.txt");
                    String pathser = context.getRealPath("/WEB-INF/classlist.txt");
                    
                    try {
                        StudentIO.addStudent(s,pathtxt);
                        StudentIO.addStudentSer(s, pathser);
                    } catch (IOException e) {
                        msg += "Unable to save student: " + e.getMessage() + "<br>";
                    }
                }
            }
            
            request.setAttribute("student", s);
            
        } catch (Exception e) {
            msg = "Servlet error: " + e.getMessage();
            URL = "/students.jsp";
        }
        if (!msg.isEmpty()) {
            request.setAttribute("s", s);
        }
        RequestDispatcher disp =               //new object
                getServletContext().getRequestDispatcher(URL);
        disp.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
