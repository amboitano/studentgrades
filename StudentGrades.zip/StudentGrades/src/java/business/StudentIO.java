
package business;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author acmor
 */
public class StudentIO {
    public static void addStudent(Student s, String path)
            throws IOException {
        File f = new File(path);
        PrintWriter out  = new PrintWriter(new FileWriter(f,true));
        out.println(s.toString());
        out.close();
         }
    public static String addStudentSer(Student s, String path) {
        String msg="";
        try {
            FileOutputStream fos = new FileOutputStream(path,true);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(s);
            oos.close();
            oos.close();
        } 
        catch (NotSerializableException e) {
            msg = "Serializable Exception: " + e.getMessage();
        }
        catch (IOException e) {
            msg = "Serial IO Exception: " + e.getMessage();
        }
        return msg;
    }
    public static ArrayList<Student> getStudentList(String path)
            throws IOException {
        ArrayList<Student> slist = new ArrayList<>();
        BufferedReader in = new BufferedReader(
        new FileReader(path));
        String s;
        s = in.readLine();
        while (s !=null) {
            Student st = parseToStudent(s);
            if (st != null) { slist.add(st); }
            s = in.readLine();
        }
        in.close();
        return slist;
    }
    private static Student parseToStudent(String s) {
        Student st = null;
        try {
        String[] svals = s.split(",");
        st = new Student();
        st.setSid(svals[0].trim());
        st.setLastnm(svals[1].trim());
        st.setFirstnm(svals[2].trim());
        st.setQ1(Double.parseDouble(svals[3].trim()));
        //st.setQ2(Double.parseDouble(svals[4].trim()));
            
            
        } catch (Exception e) {
            st = null;
        }
        
        return st;
    }
    public static ArrayList<Student> getStudentListSer(String path) {
        ArrayList<Student> slist = new ArrayList<>();
        try {
            FileInputStream fis = new FileInputStream(path);
            ObjectInputStream ois = new ObjectInputStream(fis);
            while (true) {
                Student st = (Student) ois.readObject();
                if (st != null) {
                    slist.add(st);
                    
                }else {
                    break;
                }
        }
        
            ois.close();
            fis.close();
        }
        catch (Exception e) {
            
        }
        return slist;
    
}
}
