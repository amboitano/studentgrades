
package business;

import java.io.Serializable;

/**
 *
 * @author acmor
 */
public class Student implements Serializable {
    private String sid, lastnm, firstnm, lgrade, emsg;
    private double q1, q2, q3, q4, q5, qm, mt, pr, fe, qavg, cavg;
    
    public Student () {
        this.sid = "";
        this.lastnm = "";
        this.firstnm= "";
        this.lgrade = "";
        this.emsg = "";
        this.q1 = 0;
        this.q2 = 0;
        this.q3 = 0;
        this.q4 = 0;
        this.q5 = 0;
        this.qm = 0; 
        this.mt = 0;
        this.pr = 0;
        this.fe = 0;
        this.qavg = 0;
        this.cavg = 0;
        //empty constructor 
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getLastnm() {
        return lastnm;
    }

    public void setLastnm(String lastnm) {
        this.lastnm = lastnm;
    }

    public String getFirstnm() {
        return firstnm;
    }

    public void setFirstnm(String firstnm) {
        this.firstnm = firstnm;
    }

    public String getLgrade() {
        this.lgrade = "C";
        return lgrade;
    }

    public String getEmsg() {
        return emsg;
    }

    public double getQ1() {
        return q1;
    }

    public void setQ1(double q1) {
        this.q1 = q1;
    }

    public double getQ2() {
        return q2;
    }

    public void setQ2(double q2) {
        this.q2 = q2;
    }

    public double getQ3() {
        return q3;
    }

    public void setQ3(double q3) {
        this.q3 = q3;
    }

    public double getQ4() {
        return q4;
    }

    public void setQ4(double q4) {
        this.q4 = q4;
    }

    public double getQ5() {
        return q5;
    }

    public void setQ5(double q5) {
        this.q5 = q5;
    }

    public double getQm() {
        return qm;
    }

    public void setQm(double qm) {
        this.qm = qm;
    }

    public double getMt() {
        return mt;
    }

    public void setMt(double mt) {
        this.mt = mt;
    }

    public double getPr() {
        return pr;
    }

    public void setPr(double pr) {
        this.pr = pr;
    }

    public double getFe() {
        return fe;
    }

    public void setFe(double fe) {
        this.fe = fe;
    }

    public double getQavg() {
        return qavg;
    }

    public double getCavg() {
        return cavg;
    }
    @Override
    public String toString() {
        return this.sid + "," + this.lastnm + "," + this.firstnm + "," +
                this.q1;
    }
}
